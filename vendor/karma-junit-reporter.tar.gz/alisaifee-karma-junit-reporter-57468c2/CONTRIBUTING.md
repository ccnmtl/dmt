Please see the [Contributing to Karma] guide for information on contributing to this project.

[Contributing to Karma]: https://github.com/karma-runner/karma/blob/master/CONTRIBUTING.md
